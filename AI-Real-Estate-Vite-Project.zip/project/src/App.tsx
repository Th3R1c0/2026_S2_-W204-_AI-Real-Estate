export { default } from './nz-real-estate-ai.tsx'
