import { useState, useMemo } from "react";
import type { ReactNode } from "react";
import {
  Home, Search, SlidersHorizontal, Heart, MapPin, BedDouble, Bath, Car,
  Ruler, X, Sparkles, LayoutGrid, List, ArrowUpDown, Loader2, Calendar,
  Calculator, Scale
} from "lucide-react";

type Property = {
  id: number;
  region: string;
  suburb: string;
  city: string;
  address: string;
  price: number;
  cv: number;
  propertyType: string;
  architecturalStyle: string | null;
  sunExposure: string | null;
  titleType: string;
  saleMethod: string;
  bedrooms: number;
  bathrooms: number;
  parking: number;
  floorArea: number;
  landArea: number;
  yearBuilt: number | null;
  daysOnMarket: number;
  openHome: boolean;
  features: string[];
  description: string;
  agent: string;
  isCheapest?: boolean;
};

type Filters = {
  regions: string[];
  propertyTypes: string[];
  titleTypes: string[];
  saleMethods: string[];
  features: string[];
  architecturalStyles: string[];
  sunnyOnly: boolean;
  sunOrientations: string[];
  priceMin: number | null;
  priceMax: number | null;
  bedsMin: number;
  bathsMin: number;
  parkingMin: number;
  landAreaMin: number;
  floorAreaMin: number;
  openHomesOnly: boolean;
  underCV: boolean;
  freshOnly: boolean;
  keyword: string;
};

type Chip = { type: string; value?: string; label: string };
type SortBy = "newest" | "priceAsc" | "priceDesc" | "landDesc" | "floorDesc" | "pricePerM2Asc";
type ViewMode = "grid" | "list";
type AiNote = "ai" | "fallback" | null;
type SetFilters = (f: Filters | ((prev: Filters) => Filters)) => void;

type MortgageResult = {
  loanAmount: number;
  monthlyRepayment: number;
  totalRepayment: number;
  totalInterest: number;
};

/* ---------------------------------------------------------------- */
/* Reference data                                                    */
/* ---------------------------------------------------------------- */

const REGIONS = [
  "Auckland", "Wellington", "Canterbury", "Waikato", "Bay of Plenty",
  "Otago", "Queenstown-Lakes", "Nelson-Tasman", "Hawke's Bay", "Manawatū-Whanganui"
];
const PROPERTY_TYPES = ["House", "Villa", "Apartment", "Townhouse", "Section", "Lifestyle Block"];
const ARCHITECTURAL_STYLES = [
  "Villa", "Bungalow", "Mid-Century", "Colonial", "Mediterranean",
  "Contemporary", "Modern", "Modern Farmhouse", "Alpine Contemporary"
];
const SUN_EXPOSURES = ["North", "North-East", "North-West", "East", "West", "South"];
const SUNNY_ORIENTATIONS = ["North", "North-East", "North-West"];
const TITLE_TYPES = ["Freehold", "Cross-Lease", "Unit Title", "Leasehold"];
const SALE_METHODS = ["Auction", "Deadline Sale", "Price by Negotiation", "Tender", "Fixed Price"];
const FEATURES = [
  "Heat pump", "Solar panels", "Double glazing", "EV charger",
  "Fenced yard", "Pets OK", "Off-street parking", "Water views", "Renovated",
  "Fibre ready", "Log burner"
];
const MAX_COMPARE = 4;

const TITLE_COLORS: Record<string, string> = {
  "Freehold": "#24463B",
  "Cross-Lease": "#B9803A",
  "Unit Title": "#45607A",
  "Leasehold": "#A6432D"
};

const THUMB_TONES = [
  ["#DCE7DE", "#AFC9BA"],
  ["#EDE0C8", "#D6B183"],
  ["#DCE3E8", "#AFC0CC"],
  ["#E9D9C8", "#CBA179"]
];

const PROPERTIES: Property[] = [
  { id: 1, region: "Auckland", suburb: "Ponsonby", city: "Auckland", address: "14 Franklin Road",
    price: 1650000, cv: 1550000, propertyType: "Villa", architecturalStyle: "Villa", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 3, bathrooms: 2, parking: 1, floorArea: 165, landArea: 380, yearBuilt: 1920, daysOnMarket: 5,
    openHome: true, features: ["Double glazing", "Renovated", "Off-street parking"],
    description: "A restored villa on one of Ponsonby's leafy streets, with the original bones and a north-facing sunroom that catches the day.",
    agent: "Mere Tuiono, Bayview Realty" },
  { id: 2, region: "Auckland", suburb: "Mount Eden", city: "Auckland", address: "8B Mount Eden Road",
    price: 1180000, cv: 1200000, propertyType: "House", architecturalStyle: "Mid-Century", sunExposure: "South",
    titleType: "Cross-Lease", saleMethod: "Deadline Sale",
    bedrooms: 3, bathrooms: 1, parking: 1, floorArea: 130, landArea: 300, yearBuilt: 1975, daysOnMarket: 12,
    openHome: true, features: ["Heat pump", "Fenced yard"],
    description: "Tucked behind a shared driveway, an easy-care family home a short stroll from the village shops and Eden Park.",
    agent: "Josh Petersen, Ray White Eden" },
  { id: 3, region: "Auckland", suburb: "Grey Lynn", city: "Auckland", address: "3/22 Surrey Crescent",
    price: 890000, cv: 850000, propertyType: "Townhouse", architecturalStyle: "Contemporary", sunExposure: "East",
    titleType: "Unit Title", saleMethod: "Price by Negotiation",
    bedrooms: 2, bathrooms: 1, parking: 1, floorArea: 95, landArea: 0, yearBuilt: 2018, daysOnMarket: 20,
    openHome: false, features: ["EV charger", "Double glazing", "Fibre ready"],
    description: "A tidy modern terrace with its own garage and charger, close to the cafes on Great North Road.",
    agent: "Aroha Ngata, Barfoot & Co" },
  { id: 4, region: "Auckland", suburb: "Henderson", city: "Auckland", address: "56 Universal Drive",
    price: 999000, cv: 1050000, propertyType: "House", architecturalStyle: "Contemporary", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Fixed Price",
    bedrooms: 4, bathrooms: 2, parking: 2, floorArea: 190, landArea: 650, yearBuilt: 1995, daysOnMarket: 3,
    openHome: true, features: ["Heat pump", "Solar panels", "Fenced yard", "Pets OK"],
    description: "Room to move, a fully fenced section for the kids and dog, and solar already on the roof.",
    agent: "Sina Faleolo, LJ Hooker West" },
  { id: 5, region: "Auckland", suburb: "Papakura", city: "Auckland", address: "21 Elliot Street",
    price: 749000, cv: 780000, propertyType: "House", architecturalStyle: "Bungalow", sunExposure: "West",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 3, bathrooms: 1, parking: 1, floorArea: 110, landArea: 500, yearBuilt: 1965, daysOnMarket: 30,
    openHome: false, features: ["Off-street parking"],
    description: "A solid weatherboard starter home with a full-size section, priced for a first buyer or investor.",
    agent: "Dean Ah Chee, Harcourts South" },
  { id: 6, region: "Auckland", suburb: "City Centre", city: "Auckland", address: "12F/9 Nelson Street",
    price: 465000, cv: 490000, propertyType: "Apartment", architecturalStyle: "Modern", sunExposure: "North-East",
    titleType: "Unit Title", saleMethod: "Price by Negotiation",
    bedrooms: 1, bathrooms: 1, parking: 0, floorArea: 48, landArea: 0, yearBuilt: 2016, daysOnMarket: 18,
    openHome: true, features: ["Fibre ready", "Water views"],
    description: "A north-facing one-bedroom high above the Viaduct, with harbour glimpses from the balcony.",
    agent: "Cameron Yu, City Living Realty" },
  { id: 7, region: "Auckland", suburb: "Remuera", city: "Auckland", address: "5 Victoria Avenue",
    price: 2650000, cv: 2500000, propertyType: "House", architecturalStyle: "Mediterranean", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Tender",
    bedrooms: 5, bathrooms: 3, parking: 2, floorArea: 320, landArea: 810, yearBuilt: 2005, daysOnMarket: 9,
    openHome: true, features: ["Solar panels", "Log burner", "Water views"],
    description: "A substantial family home on the ridge, with harbour glimpses and zoning for three sought-after schools.",
    agent: "Fiona Marsh, Bayleys Remuera" },
  { id: 8, region: "Wellington", suburb: "Mount Cook", city: "Wellington", address: "4/89 Buckle Street",
    price: 620000, cv: 600000, propertyType: "Apartment", architecturalStyle: "Modern", sunExposure: "South",
    titleType: "Unit Title", saleMethod: "Deadline Sale",
    bedrooms: 2, bathrooms: 1, parking: 1, floorArea: 70, landArea: 0, yearBuilt: 2010, daysOnMarket: 14,
    openHome: true, features: ["Fibre ready", "Double glazing"],
    description: "A well-insulated apartment near the basin, an easy walk to Te Aro and both universities.",
    agent: "Grace Holloway, Wellington City Realty" },
  { id: 9, region: "Wellington", suburb: "Karori", city: "Wellington", address: "17 Donald Street",
    price: 940000, cv: 900000, propertyType: "House", architecturalStyle: "Colonial", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 3, bathrooms: 2, parking: 2, floorArea: 150, landArea: 480, yearBuilt: 1988, daysOnMarket: 6,
    openHome: true, features: ["Heat pump", "Fenced yard", "Pets OK"],
    description: "A north-facing family home with a flat back lawn, close to Karori Park and the school.",
    agent: "Ben Halliday, Tommy's Karori" },
  { id: 10, region: "Wellington", suburb: "Petone", city: "Lower Hutt", address: "9B Jackson Street",
    price: 799000, cv: 820000, propertyType: "Townhouse", architecturalStyle: "Contemporary", sunExposure: "North-East",
    titleType: "Cross-Lease", saleMethod: "Price by Negotiation",
    bedrooms: 3, bathrooms: 2, parking: 1, floorArea: 120, landArea: 220, yearBuilt: 2001, daysOnMarket: 25,
    openHome: false, features: ["Heat pump"],
    description: "A sunny townhouse two streets back from the beach, close to the cafes and the Saturday market.",
    agent: "Priya Nair, Petone Property Co" },
  { id: 11, region: "Canterbury", suburb: "Riccarton", city: "Christchurch", address: "31 Rocking Horse Road",
    price: 615000, cv: 640000, propertyType: "House", architecturalStyle: "Bungalow", sunExposure: "East",
    titleType: "Freehold", saleMethod: "Fixed Price",
    bedrooms: 3, bathrooms: 1, parking: 2, floorArea: 140, landArea: 600, yearBuilt: 1978, daysOnMarket: 4,
    openHome: true, features: ["Double glazing", "Off-street parking"],
    description: "A rebuilt-standard brick and tile close to Westfield Riccarton and the number 3 bus line.",
    agent: "Wiremu Stace, Harcourts Riccarton" },
  { id: 12, region: "Canterbury", suburb: "Merivale", city: "Christchurch", address: "6 Rugby Street",
    price: 1150000, cv: 1080000, propertyType: "House", architecturalStyle: "Contemporary", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 4, bathrooms: 2, parking: 2, floorArea: 210, landArea: 700, yearBuilt: 2012, daysOnMarket: 10,
    openHome: true, features: ["Solar panels", "Fenced yard"],
    description: "A north-facing rebuild on a quiet street, an easy walk to Merivale Mall and the park.",
    agent: "Lucy Fairweather, Ray White Merivale" },
  { id: 13, region: "Canterbury", suburb: "Halswell", city: "Christchurch", address: "Lot 4 Sparks Road",
    price: 385000, cv: 370000, propertyType: "Section", architecturalStyle: null, sunExposure: null,
    titleType: "Freehold", saleMethod: "Price by Negotiation",
    bedrooms: 0, bathrooms: 0, parking: 0, floorArea: 0, landArea: 550, yearBuilt: null, daysOnMarket: 40,
    openHome: false, features: [],
    description: "A flat, cleared section ready to build on, in an established pocket of Halswell close to schools.",
    agent: "Nathan Wong, PGG Wrightson Land" },
  { id: 14, region: "Waikato", suburb: "Hillcrest", city: "Hamilton", address: "22 Boundary Road",
    price: 869000, cv: 850000, propertyType: "House", architecturalStyle: "Contemporary", sunExposure: "North-West",
    titleType: "Freehold", saleMethod: "Deadline Sale",
    bedrooms: 4, bathrooms: 2, parking: 2, floorArea: 175, landArea: 520, yearBuilt: 2008, daysOnMarket: 8,
    openHome: true, features: ["Heat pump", "Fenced yard", "Pets OK"],
    description: "A family home minutes from Waikato University, with a fenced yard and room for a trampoline.",
    agent: "Chloe Dennison, LJ Hooker Hamilton" },
  { id: 15, region: "Bay of Plenty", suburb: "Mount Maunganui", city: "Tauranga", address: "5/101 Maunganui Road",
    price: 1050000, cv: 980000, propertyType: "Apartment", architecturalStyle: "Modern", sunExposure: "North-East",
    titleType: "Unit Title", saleMethod: "Auction",
    bedrooms: 2, bathrooms: 2, parking: 1, floorArea: 90, landArea: 0, yearBuilt: 2019, daysOnMarket: 5,
    openHome: true, features: ["Water views", "Fibre ready", "EV charger"],
    description: "An easy-care apartment two minutes' walk from the base of the Mount and the main beach.",
    agent: "Ricky Tane, Bayfair Realty" },
  { id: 16, region: "Bay of Plenty", suburb: "Papamoa", city: "Tauranga", address: "14 Parton Road",
    price: 899000, cv: 870000, propertyType: "House", architecturalStyle: "Contemporary", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Fixed Price",
    bedrooms: 3, bathrooms: 2, parking: 2, floorArea: 160, landArea: 450, yearBuilt: 2015, daysOnMarket: 15,
    openHome: false, features: ["Solar panels", "Heat pump"],
    description: "A modern, low-maintenance home on the flat, a short ride from Papamoa Beach.",
    agent: "Ana Whaanga, Eves Papamoa" },
  { id: 17, region: "Otago", suburb: "St Clair", city: "Dunedin", address: "48 Bedford Street",
    price: 599000, cv: 610000, propertyType: "Villa", architecturalStyle: "Villa", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 3, bathrooms: 1, parking: 1, floorArea: 130, landArea: 400, yearBuilt: 1935, daysOnMarket: 22,
    openHome: true, features: ["Renovated"],
    description: "A character home near St Clair beach and the esplanade, recently refreshed throughout.",
    agent: "Callum Neil, Dunedin City Realty" },
  { id: 18, region: "Queenstown-Lakes", suburb: "Frankton", city: "Queenstown", address: "3/18 Grant Road",
    price: 1450000, cv: 1350000, propertyType: "Townhouse", architecturalStyle: "Modern", sunExposure: "West",
    titleType: "Freehold", saleMethod: "Deadline Sale",
    bedrooms: 3, bathrooms: 2, parking: 2, floorArea: 145, landArea: 200, yearBuilt: 2020, daysOnMarket: 7,
    openHome: true, features: ["Double glazing", "Fibre ready"],
    description: "A near-new townhouse close to the airport and the lake, built for the alpine climate.",
    agent: "Isla Fraser, Queenstown Property Group" },
  { id: 19, region: "Queenstown-Lakes", suburb: "Arrowtown", city: "Queenstown", address: "9 Ramshaw Lane",
    price: 2350000, cv: 2200000, propertyType: "House", architecturalStyle: "Alpine Contemporary", sunExposure: "North-West",
    titleType: "Freehold", saleMethod: "Tender",
    bedrooms: 4, bathrooms: 3, parking: 2, floorArea: 240, landArea: 600, yearBuilt: 2017, daysOnMarket: 12,
    openHome: false, features: ["Log burner", "Water views", "Solar panels"],
    description: "A high-spec home on the edge of Arrowtown, with mountain views from every north-facing room.",
    agent: "Tom Bracewell, Arrowtown Realty" },
  { id: 20, region: "Nelson-Tasman", suburb: "Stoke", city: "Nelson", address: "27 Songer Street",
    price: 679000, cv: 650000, propertyType: "House", architecturalStyle: "Bungalow", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Price by Negotiation",
    bedrooms: 3, bathrooms: 1, parking: 1, floorArea: 120, landArea: 480, yearBuilt: 1985, daysOnMarket: 18,
    openHome: true, features: ["Heat pump", "Fenced yard"],
    description: "A sunny, easy-care home close to the Stoke shops and the cycle trail into town.",
    agent: "Hana Ropata, Nelson Bays Realty" },
  { id: 21, region: "Hawke's Bay", suburb: "Havelock North", city: "Hastings", address: "11 Te Mata Road",
    price: 1050000, cv: 980000, propertyType: "House", architecturalStyle: "Modern Farmhouse", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Auction",
    bedrooms: 4, bathrooms: 2, parking: 2, floorArea: 200, landArea: 700, yearBuilt: 2010, daysOnMarket: 6,
    openHome: true, features: ["Solar panels", "Fenced yard", "Pets OK"],
    description: "A north-facing family home under Te Mata Peak, with a large fenced garden for kids and pets.",
    agent: "Olivia Bramwell, Bayleys Havelock North" },
  { id: 22, region: "Manawatū-Whanganui", suburb: "Whanganui East", city: "Whanganui", address: "6 Somme Parade",
    price: 429000, cv: 440000, propertyType: "House", architecturalStyle: "Bungalow", sunExposure: "East",
    titleType: "Freehold", saleMethod: "Fixed Price",
    bedrooms: 3, bathrooms: 1, parking: 1, floorArea: 110, landArea: 550, yearBuilt: 1955, daysOnMarket: 35,
    openHome: false, features: ["Off-street parking"],
    description: "A tidy river-side home with a generous section, good value for a first home or rental.",
    agent: "Marcus Reid, Whanganui Realty" },
  { id: 23, region: "Waikato", suburb: "Tamahere", city: "Hamilton", address: "142 Tamahere Estate Drive",
    price: 1780000, cv: 1650000, propertyType: "Lifestyle Block", architecturalStyle: "Modern Farmhouse", sunExposure: "North",
    titleType: "Freehold", saleMethod: "Tender",
    bedrooms: 4, bathrooms: 2, parking: 3, floorArea: 230, landArea: 20000, yearBuilt: 2014, daysOnMarket: 16,
    openHome: true, features: ["Solar panels", "Fenced yard", "Off-street parking", "Pets OK"],
    description: "A 2-hectare lifestyle block with a north-facing homestead, room for horses, and easy access to Hamilton.",
    agent: "Chloe Dennison, LJ Hooker Hamilton" }
];

/* ---------------------------------------------------------------- */
/* Helpers                                                            */
/* ---------------------------------------------------------------- */

const fmtMoney = (n: number) => "$" + Number(n).toLocaleString("en-NZ");

const initialFilters: Filters = {
  regions: [], propertyTypes: [], titleTypes: [], saleMethods: [], features: [],
  architecturalStyles: [], sunnyOnly: false, sunOrientations: [],
  priceMin: null, priceMax: null, bedsMin: 0, bathsMin: 0, parkingMin: 0,
  landAreaMin: 0, floorAreaMin: 0, openHomesOnly: false, underCV: false,
  freshOnly: false, keyword: ""
};

function toggleInArray<T>(arr: T[], val: T): T[] {
  return arr.includes(val) ? arr.filter((v) => v !== val) : [...arr, val];
}

/* US1 [#23/#28]: filter properties by property type — TDD-verified in tests/1-propertyType.test.js */
function filterByPropertyType(properties: Property[], types: string[]): Property[] {
  if (!types || types.length === 0) return properties;
  return properties.filter((p) => types.includes(p.propertyType));
}

/* US2 [#24]: filter properties by architectural style — TDD-verified in tests/2-architecturalStyle.test.js */
function filterByArchitecturalStyle(properties: Property[], styles: string[]): Property[] {
  if (!styles || styles.length === 0) return properties;
  return properties.filter((p) => p.architecturalStyle && styles.includes(p.architecturalStyle));
}

/* US3 [#27]: search by sunlight exposure / north-facing — TDD-verified in tests/3-sunExposure.test.js */
function filterBySunExposure(properties: Property[], { sunnyOnly = false, orientations = [] }: { sunnyOnly?: boolean; orientations?: string[] } = {}): Property[] {
  let result = properties;
  if (sunnyOnly) result = result.filter((p) => p.sunExposure && SUNNY_ORIENTATIONS.includes(p.sunExposure));
  if (orientations.length > 0) result = result.filter((p) => p.sunExposure && orientations.includes(p.sunExposure));
  return result;
}

/* US4 [#21]: mortgage repayment calculator — TDD-verified in tests/4-mortgageCalculator.test.js */
function calculateMortgageRepayment({ price, depositAmount, interestRatePercent, termYears }: { price: number; depositAmount: number; interestRatePercent: number; termYears: number }): MortgageResult {
  if (!termYears || termYears <= 0) throw new Error("Loan term must be a positive number of years.");
  const loanAmount = Math.max(0, price - depositAmount);
  const numPayments = termYears * 12;
  if (loanAmount === 0) return { loanAmount: 0, monthlyRepayment: 0, totalRepayment: 0, totalInterest: 0 };
  const monthlyRate = interestRatePercent / 100 / 12;
  let monthlyRepayment;
  if (monthlyRate === 0) {
    monthlyRepayment = loanAmount / numPayments;
  } else {
    const factor = Math.pow(1 + monthlyRate, numPayments);
    monthlyRepayment = (loanAmount * monthlyRate * factor) / (factor - 1);
  }
  const rounded = Math.round(monthlyRepayment);
  const totalRepayment = rounded * numPayments;
  return { loanAmount, monthlyRepayment: rounded, totalRepayment, totalInterest: totalRepayment - loanAmount };
}

/* US5 [#46/#40]: compare properties side by side — TDD-verified in tests/5-compareProperties.test.js */
function compareProperties(properties: Property[], ids: number[]): Property[] {
  if (ids.length > MAX_COMPARE) throw new Error(`You can compare at most ${MAX_COMPARE} properties at once.`);
  const byId = new Map(properties.map((p) => [p.id, p]));
  const selected = ids.map((id) => byId.get(id)).filter((p): p is Property => Boolean(p));
  if (selected.length === 0) return [];
  const cheapestPrice = Math.min(...selected.map((p) => p.price));
  return selected.map((p) => ({ ...p, isCheapest: p.price === cheapestPrice }));
}

function filterProperties(list: Property[], f: Filters): Property[] {
  let base = filterByPropertyType(list, f.propertyTypes);
  base = filterByArchitecturalStyle(base, f.architecturalStyles);
  base = filterBySunExposure(base, { sunnyOnly: f.sunnyOnly, orientations: f.sunOrientations });
  return base.filter((p) => {
    if (f.regions.length && !f.regions.includes(p.region)) return false;
    if (f.titleTypes.length && !f.titleTypes.includes(p.titleType)) return false;
    if (f.saleMethods.length && !f.saleMethods.includes(p.saleMethod)) return false;
    if (f.features.length && !f.features.every((feat) => p.features.includes(feat))) return false;
    if (f.priceMin && p.price < f.priceMin) return false;
    if (f.priceMax && p.price > f.priceMax) return false;
    if (f.bedsMin && p.bedrooms < f.bedsMin) return false;
    if (f.bathsMin && p.bathrooms < f.bathsMin) return false;
    if (f.parkingMin && p.parking < f.parkingMin) return false;
    if (f.landAreaMin && p.landArea < f.landAreaMin) return false;
    if (f.floorAreaMin && p.floorArea < f.floorAreaMin) return false;
    if (f.openHomesOnly && !p.openHome) return false;
    if (f.underCV && !(p.price <= p.cv)) return false;
    if (f.freshOnly && p.daysOnMarket > 7) return false;
    if (f.keyword && f.keyword.trim()) {
      const kw = f.keyword.toLowerCase();
      const hay = (p.address + " " + p.suburb + " " + p.city + " " + p.description).toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    return true;
  });
}

function sortProperties(list: Property[], sortBy: SortBy): Property[] {
  const arr = [...list];
  const perM2 = (p: Property) => p.price / (p.floorArea > 0 ? p.floorArea : p.landArea || 1);
  switch (sortBy) {
    case "priceAsc": return arr.sort((a, b) => a.price - b.price);
    case "priceDesc": return arr.sort((a, b) => b.price - a.price);
    case "landDesc": return arr.sort((a, b) => b.landArea - a.landArea);
    case "floorDesc": return arr.sort((a, b) => b.floorArea - a.floorArea);
    case "pricePerM2Asc": return arr.sort((a, b) => perM2(a) - perM2(b));
    case "newest":
    default: return arr.sort((a, b) => a.daysOnMarket - b.daysOnMarket);
  }
}

function buildChips(f: Filters): Chip[] {
  const chips: Chip[] = [];
  f.regions.forEach((v) => chips.push({ type: "regions", value: v, label: v }));
  f.propertyTypes.forEach((v) => chips.push({ type: "propertyTypes", value: v, label: v }));
  f.titleTypes.forEach((v) => chips.push({ type: "titleTypes", value: v, label: v }));
  f.saleMethods.forEach((v) => chips.push({ type: "saleMethods", value: v, label: v }));
  f.features.forEach((v) => chips.push({ type: "features", value: v, label: v }));
  f.architecturalStyles.forEach((v) => chips.push({ type: "architecturalStyles", value: v, label: v }));
  f.sunOrientations.forEach((v) => chips.push({ type: "sunOrientations", value: v, label: `${v}-facing` }));
  if (f.sunnyOnly) chips.push({ type: "sunnyOnly", label: "Sunny (north aspect)" });
  if (f.priceMin) chips.push({ type: "priceMin", label: `Min ${fmtMoney(f.priceMin)}` });
  if (f.priceMax) chips.push({ type: "priceMax", label: `Max ${fmtMoney(f.priceMax)}` });
  if (f.bedsMin) chips.push({ type: "bedsMin", label: `${f.bedsMin}+ beds` });
  if (f.bathsMin) chips.push({ type: "bathsMin", label: `${f.bathsMin}+ baths` });
  if (f.parkingMin) chips.push({ type: "parkingMin", label: `${f.parkingMin}+ parking` });
  if (f.landAreaMin) chips.push({ type: "landAreaMin", label: `Land ${f.landAreaMin}+ m²` });
  if (f.floorAreaMin) chips.push({ type: "floorAreaMin", label: `Floor ${f.floorAreaMin}+ m²` });
  if (f.openHomesOnly) chips.push({ type: "openHomesOnly", label: "Open homes only" });
  if (f.underCV) chips.push({ type: "underCV", label: "At/under CV" });
  if (f.freshOnly) chips.push({ type: "freshOnly", label: "New this week" });
  if (f.keyword) chips.push({ type: "keyword", label: `"${f.keyword}"` });
  return chips;
}

function naiveParse(text: string): Partial<Filters> {
  const q = text.toLowerCase();
  const result: any = { regions: [], propertyTypes: [], titleTypes: [], saleMethods: [], features: [],
    architecturalStyles: [], sunnyOnly: false, sunOrientations: [],
    priceMin: null, priceMax: null, bedsMin: 0, bathsMin: 0, openHomesOnly: false, underCV: false, keyword: "" };
  const money = q.match(/(?:under|below|less than|up to)\s*\$?\s*([\d,.]+)\s*(m|million|k)?/);
  if (money) {
    let val = parseFloat(money[1].replace(/,/g, ""));
    if (money[2] && money[2][0] === "m") val *= 1000000;
    else if (money[2] === "k") val *= 1000;
    result.priceMax = val;
  }
  const bed = q.match(/(\d+)\s*\+?\s*bed/);
  if (bed) result.bedsMin = parseInt(bed[1], 10);
  const bath = q.match(/(\d+)\s*\+?\s*bath/);
  if (bath) result.bathsMin = parseInt(bath[1], 10);
  REGIONS.forEach((r) => { if (q.includes(r.toLowerCase())) result.regions.push(r); });
  PROPERTY_TYPES.forEach((t) => { if (q.includes(t.toLowerCase())) result.propertyTypes.push(t); });
  TITLE_TYPES.forEach((t) => { if (q.includes(t.toLowerCase())) result.titleTypes.push(t); });
  FEATURES.forEach((f) => { if (q.includes(f.toLowerCase())) result.features.push(f); });
  ARCHITECTURAL_STYLES.forEach((s) => { if (q.includes(s.toLowerCase())) result.architecturalStyles.push(s); });
  if (q.includes("sunny") || q.includes("north-facing") || q.includes("north facing")) result.sunnyOnly = true;
  SUN_EXPOSURES.forEach((o) => { if (q.includes(o.toLowerCase() + "-facing") || q.includes(o.toLowerCase() + " facing")) result.sunOrientations.push(o); });
  if (q.includes("open home")) result.openHomesOnly = true;
  if (q.includes("under cv") || q.includes("under council value")) result.underCV = true;
  if (!result.regions.length) {
    const suburbMatch = PROPERTIES.find((p) => q.includes(p.suburb.toLowerCase()));
    if (suburbMatch) { result.keyword = suburbMatch.suburb; result.regions = [suburbMatch.region]; }
  }
  return result;
}

/* ---------------------------------------------------------------- */
/* Styles                                                             */
/* ---------------------------------------------------------------- */

const styles = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap');

.hg-app { --ink:#1B2420; --paper:#F1F0E8; --moss:#24463B; --moss-light:#3E6B57; --clay:#B9803A;
  --slate:#45607A; --line:#DAD6C9; --card:#FFFFFF; --danger:#A6432D; --muted:#6B7268;
  font-family:'Inter',system-ui,sans-serif; color:var(--ink); background:var(--paper);
  min-height:100vh; line-height:1.5; }
.hg-app * { box-sizing:border-box; }
.hg-serif { font-family:'Fraunces', serif; }

.hg-header { display:flex; justify-content:space-between; align-items:center; padding:18px 32px;
  border-bottom:1px solid var(--line); position:sticky; top:0; background:var(--paper); z-index:30; }
.hg-logo { font-family:'Fraunces'; font-size:22px; font-weight:600; color:var(--moss); display:flex; align-items:center; gap:8px; }
.hg-logo-mark { width:30px; height:30px; border-radius:8px; background:var(--moss); display:flex; align-items:center; justify-content:center; color:#fff; }
.hg-header-actions { display:flex; align-items:center; gap:10px; }
.hg-saved-toggle { display:flex; align-items:center; gap:6px; background:var(--card); border:1px solid var(--line);
  padding:9px 14px; border-radius:20px; font-size:14px; font-weight:500; cursor:pointer; color:var(--ink); }
.hg-saved-toggle.active { background:var(--moss); color:#fff; border-color:var(--moss); }

.hg-hero { padding:52px 32px 34px; max-width:820px; }
.hg-hero h1 { font-family:'Fraunces'; font-weight:500; font-size:clamp(30px,4vw,46px); line-height:1.08; margin:0 0 14px; letter-spacing:-0.01em; }
.hg-hero p.sub { font-size:16px; color:var(--muted); margin:0 0 26px; max-width:560px; }

.hg-ai-bar { display:flex; gap:8px; background:var(--card); border:1.5px solid var(--moss); border-radius:14px;
  padding:6px 6px 6px 18px; align-items:center; box-shadow:5px 5px 0 rgba(36,70,59,0.09); max-width:680px; }
.hg-ai-bar input { flex:1; border:none; outline:none; font-size:15px; background:transparent; color:var(--ink); font-family:'Inter'; padding:10px 0; }
.hg-ai-bar input::placeholder { color:#9a9d92; }
.hg-ai-submit { display:flex; align-items:center; gap:8px; background:var(--moss); color:#fff; border:none;
  padding:11px 18px; border-radius:9px; font-size:14px; font-weight:600; cursor:pointer; white-space:nowrap; }
.hg-ai-submit:disabled { opacity:0.7; cursor:default; }
.hg-spin { animation: hg-rotate 0.8s linear infinite; }
@keyframes hg-rotate { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
.hg-ai-examples { display:flex; flex-wrap:wrap; gap:8px; margin-top:14px; }
.hg-example-pill { background:transparent; border:1px solid var(--line); color:var(--muted); font-size:12.5px;
  padding:6px 12px; border-radius:20px; cursor:pointer; }
.hg-example-pill:hover { border-color:var(--moss); color:var(--moss); }
.hg-ai-note { margin-top:12px; font-size:13px; color:var(--clay); display:flex; align-items:center; gap:6px; }

.hg-stats { display:flex; gap:0; margin-top:30px; max-width:520px; }
.hg-stat { padding:0 22px; border-left:1px solid var(--line); }
.hg-stat:first-child { padding-left:0; border-left:none; }
.hg-stat b { display:block; font-family:'Fraunces'; font-size:22px; font-weight:600; }
.hg-stat span { font-size:12.5px; color:var(--muted); }

.hg-main { display:grid; grid-template-columns:272px 1fr; gap:26px; padding:8px 32px 110px; max-width:1360px; margin:0 auto; }
@media (max-width:880px) { .hg-main { grid-template-columns:1fr; } .hg-sidebar { display:none; } }

.hg-sidebar { position:sticky; top:82px; align-self:start; background:var(--card); border:1px solid var(--line);
  border-radius:12px; padding:20px; max-height:calc(100vh - 100px); overflow-y:auto; }
.hg-filter-group { padding:16px 0; border-top:1px solid var(--line); }
.hg-filter-group:first-child { padding-top:0; border-top:none; }
.hg-filter-title { font-size:14px; font-weight:600; margin:0 0 12px; display:flex; justify-content:space-between; align-items:center; }
.hg-clear-all { font-size:12.5px; color:var(--moss); background:none; border:none; cursor:pointer; font-weight:600; }

.hg-pill-row { display:flex; flex-wrap:wrap; gap:7px; }
.hg-pill { border:1px solid var(--line); background:#fff; padding:6px 12px; border-radius:20px; font-size:13px; cursor:pointer; color:var(--ink); }
.hg-pill.active { background:var(--moss); border-color:var(--moss); color:#fff; }

.hg-price-inputs { display:flex; gap:8px; margin-bottom:10px; }
.hg-price-inputs input { width:100%; border:1px solid var(--line); border-radius:8px; padding:8px 10px; font-size:13.5px; font-family:'Inter'; }

.hg-check-list { display:flex; flex-direction:column; gap:9px; }
.hg-check-row { display:flex; align-items:center; gap:9px; font-size:13.5px; cursor:pointer; }
.hg-check-row input { accent-color:var(--moss); width:15px; height:15px; cursor:pointer; }

.hg-num-input { display:flex; align-items:center; gap:8px; }
.hg-num-input input { width:90px; border:1px solid var(--line); border-radius:8px; padding:7px 9px; font-size:13.5px; }
.hg-num-input span { font-size:12.5px; color:var(--muted); }

.hg-switch-row { display:flex; align-items:center; justify-content:space-between; padding:7px 0; }
.hg-switch-row label { font-size:13.5px; }
.hg-switch { position:relative; width:38px; height:22px; flex-shrink:0; }
.hg-switch input { opacity:0; width:0; height:0; }
.hg-switch-track { position:absolute; inset:0; background:#DDDACD; border-radius:20px; transition:0.15s; cursor:pointer; }
.hg-switch input:checked + .hg-switch-track { background:var(--moss); }
.hg-switch-track:before { content:""; position:absolute; width:16px; height:16px; left:3px; top:3px; background:#fff; border-radius:50%; transition:0.15s; }
.hg-switch input:checked + .hg-switch-track:before { transform:translateX(16px); }

.hg-legend { display:flex; flex-wrap:wrap; gap:8px; font-size:11.5px; color:var(--muted); }
.hg-legend-item { display:flex; align-items:center; gap:5px; }
.hg-legend-swatch { width:9px; height:9px; border-radius:2px; }

.hg-toolbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:12px; }
.hg-result-count { font-size:14.5px; color:var(--muted); }
.hg-result-count b { color:var(--ink); }
.hg-toolbar-right { display:flex; align-items:center; gap:10px; }
.hg-sort-select { border:1px solid var(--line); border-radius:8px; padding:8px 10px; font-size:13.5px; background:#fff; color:var(--ink); font-family:'Inter'; }
.hg-view-toggle { display:flex; border:1px solid var(--line); border-radius:8px; overflow:hidden; }
.hg-view-toggle button { background:#fff; border:none; padding:8px 10px; cursor:pointer; display:flex; color:var(--muted); }
.hg-view-toggle button.active { background:var(--moss); color:#fff; }
.hg-mobile-filter-btn { display:none; align-items:center; gap:6px; background:var(--card); border:1px solid var(--line);
  padding:8px 14px; border-radius:20px; font-size:13.5px; font-weight:500; cursor:pointer; }
@media (max-width:880px) { .hg-mobile-filter-btn { display:flex; } }

.hg-chips { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:18px; }
.hg-chip { display:inline-flex; align-items:center; gap:6px; background:#fff; border:1px solid var(--line);
  padding:6px 8px 6px 12px; border-radius:20px; font-size:12.5px; }
.hg-chip button { background:none; border:none; cursor:pointer; display:flex; color:var(--muted); padding:2px; }

.hg-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(270px,1fr)); gap:20px; }
.hg-list { display:flex; flex-direction:column; gap:14px; }

.hg-card { background:var(--card); border:1px solid var(--line); border-left:4px solid var(--moss); border-radius:10px;
  overflow:hidden; cursor:pointer; transition:box-shadow .15s ease, transform .15s ease; }
.hg-card:hover { box-shadow:0 10px 22px rgba(27,36,32,0.09); transform:translateY(-2px); }
.hg-list .hg-card { display:flex; }
.hg-thumb { height:158px; position:relative; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.hg-list .hg-thumb { width:220px; height:auto; }
.hg-badge-sale { position:absolute; top:10px; left:10px; background:rgba(255,255,255,.92); font-size:11px; font-weight:600;
  padding:4px 10px; border-radius:20px; color:var(--ink); }
.hg-save-btn { position:absolute; top:10px; right:10px; background:rgba(255,255,255,.88); border:none; border-radius:50%;
  width:32px; height:32px; display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--danger); }
.hg-price-badge { position:absolute; bottom:10px; left:10px; background:var(--ink); color:#fff; font-family:'Fraunces';
  font-weight:500; padding:6px 12px; border-radius:8px; font-size:16px; }
.hg-card-body { padding:14px 16px 16px; flex:1; }
.hg-card-address { font-weight:600; font-size:15px; margin:0 0 2px; }
.hg-card-suburb { font-size:12.5px; color:var(--muted); display:flex; align-items:center; gap:4px; margin-bottom:10px; }
.hg-spec-row { display:flex; gap:14px; margin-bottom:10px; flex-wrap:wrap; }
.hg-spec { display:flex; align-items:center; gap:5px; font-size:13px; color:var(--ink); }
.hg-tag-row { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px; }
.hg-tag { font-size:11px; background:#F1F0E8; border:1px solid var(--line); padding:3px 8px; border-radius:12px; color:var(--muted); }
.hg-card-meta { font-size:12px; color:var(--muted); display:flex; justify-content:space-between; align-items:center; }
.hg-compare-row { display:flex; align-items:center; gap:7px; font-size:12px; color:var(--muted); margin-top:10px; padding-top:10px; border-top:1px solid var(--line); cursor:pointer; }
.hg-compare-row input { accent-color:var(--moss); width:14px; height:14px; cursor:pointer; }

.hg-empty { text-align:center; padding:70px 20px; color:var(--muted); }
.hg-empty button { margin-top:14px; background:var(--moss); color:#fff; border:none; padding:10px 18px; border-radius:8px; cursor:pointer; font-weight:600; }

.hg-overlay { position:fixed; inset:0; background:rgba(27,36,32,.55); z-index:100; display:flex; align-items:center; justify-content:center; padding:20px; }
.hg-modal { background:#fff; border-radius:16px; max-width:620px; width:100%; max-height:85vh; overflow-y:auto; padding:0; position:relative; }
.hg-modal-close { position:absolute; top:14px; right:14px; background:rgba(255,255,255,.9); border:none; border-radius:50%;
  width:34px; height:34px; display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:2; }
.hg-modal-thumb { height:220px; position:relative; }
.hg-modal-body { padding:26px 28px 30px; }
.hg-modal-price { font-family:'Fraunces'; font-size:30px; font-weight:600; margin:0 0 4px; }
.hg-modal-cv { font-size:13px; color:var(--muted); margin:0 0 16px; }
.hg-modal-address { font-size:16px; font-weight:600; margin:0 0 2px; }
.hg-modal-suburb { font-size:13.5px; color:var(--muted); margin:0 0 18px; }
.hg-modal-specs { display:flex; gap:20px; padding:14px 0; border-top:1px solid var(--line); border-bottom:1px solid var(--line); margin-bottom:18px; flex-wrap:wrap; }
.hg-modal-desc { font-size:14.5px; line-height:1.65; margin-bottom:18px; }
.hg-modal-section-title { font-size:13px; font-weight:600; margin:0 0 10px; }
.hg-modal-tags { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:20px; }
.hg-modal-agent { font-size:13.5px; color:var(--muted); margin-bottom:18px; }
.hg-cta-btn { width:100%; background:var(--moss); color:#fff; border:none; padding:13px; border-radius:9px; font-weight:600; font-size:14.5px; cursor:pointer; }
.hg-demo-note { font-size:12px; color:var(--muted); text-align:center; margin-top:10px; }
.hg-enquiry-sent { text-align:center; font-size:13.5px; color:var(--moss); font-weight:600; padding:13px; }

.hg-drawer-overlay { position:fixed; inset:0; background:rgba(27,36,32,.5); z-index:90; }
.hg-drawer { position:fixed; top:0; left:0; bottom:0; width:82%; max-width:340px; background:var(--card); z-index:95;
  overflow-y:auto; padding:20px; }
.hg-drawer-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
.hg-drawer-apply { position:sticky; bottom:0; background:var(--moss); color:#fff; border:none; width:100%; padding:13px;
  border-radius:9px; font-weight:600; margin-top:16px; cursor:pointer; }

.hg-compare-bar { position:fixed; bottom:0; left:0; right:0; background:var(--ink); color:#fff; z-index:80;
  display:flex; align-items:center; justify-content:space-between; padding:14px 32px; }
.hg-compare-bar-actions { display:flex; align-items:center; gap:10px; }
.hg-compare-view-btn { background:var(--clay); color:#fff; border:none; padding:10px 18px; border-radius:8px; font-weight:600; cursor:pointer; }
.hg-compare-view-btn:disabled { opacity:0.55; cursor:default; }
.hg-compare-clear-btn { background:transparent; color:#fff; border:1px solid rgba(255,255,255,.4); padding:10px 14px; border-radius:8px; cursor:pointer; }

.hg-compare-table { width:100%; border-collapse:collapse; font-size:13.5px; }
.hg-compare-table th, .hg-compare-table td { padding:10px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
.hg-compare-table th { font-family:'Fraunces'; font-weight:500; font-size:15px; }
.hg-compare-table tr td:first-child, .hg-compare-table tr th:first-child { color:var(--muted); font-weight:600; font-size:12px; white-space:nowrap; }
.hg-cheapest-badge { display:inline-block; margin-top:4px; font-size:10.5px; background:var(--moss); color:#fff; padding:2px 8px; border-radius:10px; }

.hg-calc-row { display:flex; flex-direction:column; gap:6px; margin-bottom:16px; }
.hg-calc-row label { font-size:13px; font-weight:600; }
.hg-calc-row input { border:1px solid var(--line); border-radius:8px; padding:10px 12px; font-size:14px; font-family:'Inter'; }
.hg-calc-result { background:var(--paper); border-radius:10px; padding:18px; margin-top:6px; }
.hg-calc-result .big { font-family:'Fraunces'; font-size:28px; font-weight:600; margin:0 0 2px; }
.hg-calc-result .label { font-size:12.5px; color:var(--muted); margin:0 0 14px; }
.hg-calc-breakdown { display:flex; justify-content:space-between; font-size:13px; padding:6px 0; border-top:1px solid var(--line); }
.hg-header-icon-btn { background:var(--card); border:1px solid var(--line); border-radius:20px; padding:9px 14px;
  font-size:13.5px; font-weight:500; cursor:pointer; display:flex; align-items:center; gap:6px; color:var(--ink); }
.hg-remove-compare-btn { margin-top:8px; padding:5px 10px; font-size:11px; background:transparent; color:var(--danger);
  border:1px solid var(--line); border-radius:14px; cursor:pointer; font-weight:600; }
`;

/* ---------------------------------------------------------------- */
/* Filter panel                                                       */
/* ---------------------------------------------------------------- */

function FilterPanel({ filters, setFilters }: { filters: Filters; setFilters: SetFilters }) {
  const set = (patch: Partial<Filters>) => setFilters((prev) => ({ ...prev, ...patch }) as Filters);

  return (
    <>
      <div className="hg-filter-group">
        <p className="hg-filter-title">
          Region
          <button className="hg-clear-all" onClick={() => setFilters(initialFilters)}>Clear all</button>
        </p>
        <div className="hg-pill-row">
          {REGIONS.map((r) => (
            <button key={r} className={"hg-pill" + (filters.regions.includes(r) ? " active" : "")}
              onClick={() => set({ regions: toggleInArray(filters.regions, r) })}>{r}</button>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Suburb or address</p>
        <input type="text" placeholder="e.g. Ponsonby, Riccarton..." value={filters.keyword}
          onChange={(e) => set({ keyword: e.target.value })}
          style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 8, padding: "8px 10px", fontSize: 13.5 }} />
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Price</p>
        <div className="hg-price-inputs">
          <input type="number" placeholder="Min $" value={filters.priceMin || ""}
            onChange={(e) => set({ priceMin: e.target.value ? Number(e.target.value) : null })} />
          <input type="number" placeholder="Max $" value={filters.priceMax || ""}
            onChange={(e) => set({ priceMax: e.target.value ? Number(e.target.value) : null })} />
        </div>
        <div className="hg-pill-row">
          <button className="hg-pill" onClick={() => set({ priceMin: null, priceMax: 600000 })}>Under $600k</button>
          <button className="hg-pill" onClick={() => set({ priceMin: 600000, priceMax: 900000 })}>$600k–$900k</button>
          <button className="hg-pill" onClick={() => set({ priceMin: 900000, priceMax: 1200000 })}>$900k–$1.2m</button>
          <button className="hg-pill" onClick={() => set({ priceMin: 1200000, priceMax: null })}>$1.2m+</button>
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Bedrooms</p>
        <div className="hg-pill-row">
          {[0, 1, 2, 3, 4, 5].map((n) => (
            <button key={n} className={"hg-pill" + (filters.bedsMin === n ? " active" : "")}
              onClick={() => set({ bedsMin: n })}>{n === 0 ? "Any" : n + "+"}</button>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Bathrooms</p>
        <div className="hg-pill-row">
          {[0, 1, 2, 3].map((n) => (
            <button key={n} className={"hg-pill" + (filters.bathsMin === n ? " active" : "")}
              onClick={() => set({ bathsMin: n })}>{n === 0 ? "Any" : n + "+"}</button>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Parking</p>
        <div className="hg-pill-row">
          {[0, 1, 2].map((n) => (
            <button key={n} className={"hg-pill" + (filters.parkingMin === n ? " active" : "")}
              onClick={() => set({ parkingMin: n })}>{n === 0 ? "Any" : n + "+"}</button>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Property type</p>
        <div className="hg-check-list">
          {PROPERTY_TYPES.map((t) => (
            <label key={t} className="hg-check-row">
              <input type="checkbox" checked={filters.propertyTypes.includes(t)}
                onChange={() => set({ propertyTypes: toggleInArray(filters.propertyTypes, t) })} />
              {t}
            </label>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Architectural style</p>
        <div className="hg-check-list">
          {ARCHITECTURAL_STYLES.map((s) => (
            <label key={s} className="hg-check-row">
              <input type="checkbox" checked={filters.architecturalStyles.includes(s)}
                onChange={() => set({ architecturalStyles: toggleInArray(filters.architecturalStyles, s) })} />
              {s}
            </label>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Sunlight exposure</p>
        <div className="hg-switch-row" style={{ marginBottom: 10 }}>
          <label>Sunny homes only (north aspect)</label>
          <span className="hg-switch">
            <input type="checkbox" checked={filters.sunnyOnly} onChange={(e) => set({ sunnyOnly: e.target.checked })} />
            <span className="hg-switch-track" />
          </span>
        </div>
        <div className="hg-pill-row">
          {SUN_EXPOSURES.map((o) => (
            <button key={o} className={"hg-pill" + (filters.sunOrientations.includes(o) ? " active" : "")}
              onClick={() => set({ sunOrientations: toggleInArray(filters.sunOrientations, o) })}>{o}</button>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Title type</p>
        <div className="hg-check-list">
          {TITLE_TYPES.map((t) => (
            <label key={t} className="hg-check-row">
              <input type="checkbox" checked={filters.titleTypes.includes(t)}
                onChange={() => set({ titleTypes: toggleInArray(filters.titleTypes, t) })} />
              {t}
            </label>
          ))}
        </div>
        <div className="hg-legend" style={{ marginTop: 10 }}>
          {TITLE_TYPES.map((t) => (
            <span key={t} className="hg-legend-item">
              <span className="hg-legend-swatch" style={{ background: TITLE_COLORS[t] }} />{t}
            </span>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Sale method</p>
        <div className="hg-check-list">
          {SALE_METHODS.map((t) => (
            <label key={t} className="hg-check-row">
              <input type="checkbox" checked={filters.saleMethods.includes(t)}
                onChange={() => set({ saleMethods: toggleInArray(filters.saleMethods, t) })} />
              {t}
            </label>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Land &amp; floor area</p>
        <div className="hg-num-input" style={{ marginBottom: 8 }}>
          <input type="number" value={filters.landAreaMin || ""} placeholder="0"
            onChange={(e) => set({ landAreaMin: e.target.value ? Number(e.target.value) : 0 })} />
          <span>m² land, minimum</span>
        </div>
        <div className="hg-num-input">
          <input type="number" value={filters.floorAreaMin || ""} placeholder="0"
            onChange={(e) => set({ floorAreaMin: e.target.value ? Number(e.target.value) : 0 })} />
          <span>m² floor, minimum</span>
        </div>
      </div>

      <div className="hg-filter-group">
        <p className="hg-filter-title">Features</p>
        <div className="hg-check-list">
          {FEATURES.map((f) => (
            <label key={f} className="hg-check-row">
              <input type="checkbox" checked={filters.features.includes(f)}
                onChange={() => set({ features: toggleInArray(filters.features, f) })} />
              {f}
            </label>
          ))}
        </div>
      </div>

      <div className="hg-filter-group">
        <div className="hg-switch-row">
          <label>Open homes only</label>
          <span className="hg-switch">
            <input type="checkbox" checked={filters.openHomesOnly} onChange={(e) => set({ openHomesOnly: e.target.checked })} />
            <span className="hg-switch-track" />
          </span>
        </div>
        <div className="hg-switch-row">
          <label>At or under council value (CV)</label>
          <span className="hg-switch">
            <input type="checkbox" checked={filters.underCV} onChange={(e) => set({ underCV: e.target.checked })} />
            <span className="hg-switch-track" />
          </span>
        </div>
        <div className="hg-switch-row">
          <label>New this week (≤7 days)</label>
          <span className="hg-switch">
            <input type="checkbox" checked={filters.freshOnly} onChange={(e) => set({ freshOnly: e.target.checked })} />
            <span className="hg-switch-track" />
          </span>
        </div>
      </div>
    </>
  );
}

/* ---------------------------------------------------------------- */
/* Property card                                                      */
/* ---------------------------------------------------------------- */

function PropertyCard({ p, isSaved, onToggleSave, onOpen, isComparing, onToggleCompare }: { p: Property; isSaved: boolean; onToggleSave: (id: number) => void; onOpen: (p: Property) => void; isComparing: boolean; onToggleCompare: (id: number) => void }) {
  const tone = THUMB_TONES[p.id % THUMB_TONES.length];
  return (
    <div className="hg-card" style={{ borderLeftColor: TITLE_COLORS[p.titleType] }} onClick={() => onOpen(p)}>
      <div className="hg-thumb" style={{ background: `linear-gradient(135deg, ${tone[0]}, ${tone[1]})` }}>
        <Home size={44} color="#1B2420" opacity={0.28} />
        <span className="hg-badge-sale">{p.saleMethod}</span>
        <button className="hg-save-btn" onClick={(e) => { e.stopPropagation(); onToggleSave(p.id); }}>
          <Heart size={16} fill={isSaved ? "#A6432D" : "none"} />
        </button>
        <span className="hg-price-badge">{fmtMoney(p.price)}</span>
      </div>
      <div className="hg-card-body">
        <p className="hg-card-address">{p.address}</p>
        <p className="hg-card-suburb"><MapPin size={12} />{p.suburb}, {p.city}</p>
        <div className="hg-spec-row">
          <span className="hg-spec"><BedDouble size={14} />{p.bedrooms}</span>
          <span className="hg-spec"><Bath size={14} />{p.bathrooms}</span>
          <span className="hg-spec"><Car size={14} />{p.parking}</span>
          {p.floorArea > 0 && <span className="hg-spec"><Ruler size={14} />{p.floorArea}m²</span>}
        </div>
        <div className="hg-tag-row">
          <span className="hg-tag">{p.titleType}</span>
          {p.architecturalStyle && <span className="hg-tag">{p.architecturalStyle}</span>}
          {p.features.slice(0, 1).map((f) => <span key={f} className="hg-tag">{f}</span>)}
        </div>
        <div className="hg-card-meta">
          <span>{p.daysOnMarket}d on market</span>
          {p.openHome && <span style={{ display: "flex", alignItems: "center", gap: 4, color: "var(--moss)" }}><Calendar size={12} />Open home</span>}
        </div>
        <label className="hg-compare-row" onClick={(e) => e.stopPropagation()}>
          <input type="checkbox" checked={isComparing} onChange={() => onToggleCompare(p.id)} />
          Add to compare
        </label>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Detail modal                                                       */
/* ---------------------------------------------------------------- */

function PropertyModal({ p, onClose, isSaved, onToggleSave }: { p: Property; onClose: () => void; isSaved: boolean; onToggleSave: (id: number) => void }) {
  const [enquired, setEnquired] = useState(false);
  const tone = THUMB_TONES[p.id % THUMB_TONES.length];
  const cvDiff = p.price - p.cv;

  return (
    <div className="hg-overlay" onClick={onClose}>
      <div className="hg-modal" onClick={(e) => e.stopPropagation()}>
        <button className="hg-modal-close" onClick={onClose}><X size={18} /></button>
        <div className="hg-modal-thumb" style={{ background: `linear-gradient(135deg, ${tone[0]}, ${tone[1]})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Home size={64} color="#1B2420" opacity={0.28} />
          <button className="hg-save-btn" style={{ position: "absolute", top: 14, right: 58 }} onClick={() => onToggleSave(p.id)}>
            <Heart size={16} fill={isSaved ? "#A6432D" : "none"} />
          </button>
        </div>
        <div className="hg-modal-body">
          <p className="hg-modal-price">{fmtMoney(p.price)}</p>
          <p className="hg-modal-cv">
            CV {fmtMoney(p.cv)} &middot; {cvDiff <= 0 ? `${fmtMoney(Math.abs(cvDiff))} under CV` : `${fmtMoney(cvDiff)} over CV`}
          </p>
          <p className="hg-modal-address">{p.address}</p>
          <p className="hg-modal-suburb">{p.suburb}, {p.city} &middot; {p.region}</p>

          <div className="hg-modal-specs">
            <span className="hg-spec"><BedDouble size={15} />{p.bedrooms} bed</span>
            <span className="hg-spec"><Bath size={15} />{p.bathrooms} bath</span>
            <span className="hg-spec"><Car size={15} />{p.parking} park</span>
            {p.floorArea > 0 && <span className="hg-spec"><Ruler size={15} />{p.floorArea}m² floor</span>}
            {p.landArea > 0 && <span className="hg-spec"><Ruler size={15} />{p.landArea}m² land</span>}
          </div>

          <p className="hg-modal-desc">{p.description}</p>

          <p className="hg-modal-section-title">Details</p>
          <div className="hg-modal-tags">
            <span className="hg-tag">{p.titleType}</span>
            <span className="hg-tag">{p.saleMethod}</span>
            {p.yearBuilt && <span className="hg-tag">Built {p.yearBuilt}</span>}
            <span className="hg-tag">{p.daysOnMarket} days on market</span>
            {p.openHome && <span className="hg-tag">Open home this weekend</span>}
          </div>

          {p.features.length > 0 && (
            <>
              <p className="hg-modal-section-title">Features</p>
              <div className="hg-modal-tags">
                {p.features.map((f) => <span key={f} className="hg-tag">{f}</span>)}
              </div>
            </>
          )}

          <p className="hg-modal-agent">Listed by {p.agent}</p>

          {enquired ? (
            <p className="hg-enquiry-sent">Enquiry noted — the agent would be notified in a real listing.</p>
          ) : (
            <button className="hg-cta-btn" onClick={() => setEnquired(true)}>Register interest</button>
          )}
          <p className="hg-demo-note">This is a demo — no enquiry is actually sent anywhere.</p>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Mortgage calculator (US4 #21)                                     */
/* ---------------------------------------------------------------- */

function MortgageCalculator({ onClose, initialPrice }: { onClose: () => void; initialPrice?: number }) {
  const [price, setPrice] = useState(initialPrice || 800000);
  const [depositPercent, setDepositPercent] = useState(20);
  const [rate, setRate] = useState(6);
  const [term, setTerm] = useState(30);
  const [error, setError] = useState<string | null>(null);

  let result: MortgageResult | null = null;
  try {
    const depositAmount = Math.round(price * (depositPercent / 100));
    result = calculateMortgageRepayment({ price, depositAmount, interestRatePercent: rate, termYears: term });
    if (error) setError(null);
  } catch (e) {
    if (!error) setError((e as Error).message);
  }

  return (
    <div className="hg-overlay" onClick={onClose}>
      <div className="hg-modal" style={{ maxWidth: 480 }} onClick={(e) => e.stopPropagation()}>
        <button className="hg-modal-close" onClick={onClose}><X size={18} /></button>
        <div className="hg-modal-body" style={{ paddingTop: 30 }}>
          <p className="hg-serif" style={{ fontSize: 22, fontWeight: 600, margin: "0 0 4px", display: "flex", alignItems: "center", gap: 8 }}>
            <Calculator size={20} /> Mortgage calculator
          </p>
          <p style={{ fontSize: 13.5, color: "var(--muted)", marginBottom: 22 }}>A quick estimate — not financial advice.</p>

          <div className="hg-calc-row">
            <label>Purchase price ($)</label>
            <input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value) || 0)} />
          </div>
          <div className="hg-calc-row">
            <label>Deposit (% of price)</label>
            <input type="number" value={depositPercent} min="0" max="100" onChange={(e) => setDepositPercent(Number(e.target.value) || 0)} />
          </div>
          <div className="hg-calc-row">
            <label>Interest rate (% p.a.)</label>
            <input type="number" step="0.1" value={rate} onChange={(e) => setRate(Number(e.target.value) || 0)} />
          </div>
          <div className="hg-calc-row">
            <label>Loan term (years)</label>
            <input type="number" value={term} onChange={(e) => setTerm(Number(e.target.value) || 0)} />
          </div>

          {error ? (
            <div className="hg-calc-result"><p style={{ color: "var(--danger)", margin: 0 }}>{error}</p></div>
          ) : result && (
            <div className="hg-calc-result">
              <p className="big hg-serif">{fmtMoney(result.monthlyRepayment)}<span style={{ fontSize: 14, fontWeight: 400 }}> / month</span></p>
              <p className="label">Estimated repayment on a {fmtMoney(result.loanAmount)} loan</p>
              <div className="hg-calc-breakdown"><span>Loan amount</span><span>{fmtMoney(result.loanAmount)}</span></div>
              <div className="hg-calc-breakdown"><span>Total interest over {term} years</span><span>{fmtMoney(result.totalInterest)}</span></div>
              <div className="hg-calc-breakdown"><span>Total repaid</span><span>{fmtMoney(result.totalRepayment)}</span></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Side-by-side comparison (US5 #46/#40)                             */
/* ---------------------------------------------------------------- */

function CompareModal({ properties, onClose, onRemove }: { properties: Property[]; onClose: () => void; onRemove: (id: number) => void }) {
  const rows: { label: string; render: (p: Property) => ReactNode }[] = [
    { label: "Price", render: (p) => <>{fmtMoney(p.price)}{p.isCheapest && <span className="hg-cheapest-badge">Cheapest</span>}</> },
    { label: "Suburb", render: (p) => `${p.suburb}, ${p.city}` },
    { label: "Type", render: (p) => p.propertyType },
    { label: "Style", render: (p) => p.architecturalStyle || "—" },
    { label: "Sun aspect", render: (p) => p.sunExposure ? `${p.sunExposure}-facing` : "—" },
    { label: "Title type", render: (p) => p.titleType },
    { label: "Bed / Bath / Park", render: (p) => `${p.bedrooms} / ${p.bathrooms} / ${p.parking}` },
    { label: "Floor area", render: (p) => p.floorArea > 0 ? `${p.floorArea}m²` : "—" },
    { label: "Land area", render: (p) => p.landArea > 0 ? `${p.landArea}m²` : "—" },
    { label: "Days on market", render: (p) => p.daysOnMarket }
  ];
  return (
    <div className="hg-overlay" onClick={onClose}>
      <div className="hg-modal" style={{ maxWidth: 760 }} onClick={(e) => e.stopPropagation()}>
        <button className="hg-modal-close" onClick={onClose}><X size={18} /></button>
        <div className="hg-modal-body" style={{ paddingTop: 30, overflowX: "auto" }}>
          <p className="hg-serif" style={{ fontSize: 22, fontWeight: 600, margin: "0 0 18px", display: "flex", alignItems: "center", gap: 8 }}>
            <Scale size={20} /> Comparing {properties.length} homes
          </p>
          <table className="hg-compare-table">
            <thead>
              <tr>
                <th></th>
                {properties.map((p) => (
                  <th key={p.id}>
                    {p.address}
                    <div>
                      <button className="hg-remove-compare-btn" onClick={() => onRemove(p.id)}>Remove</button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label}>
                  <td>{row.label}</td>
                  {properties.map((p) => <td key={p.id}>{row.render(p)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Main app                                                           */
/* ---------------------------------------------------------------- */

export default function App() {
  const [filters, setFilters] = useState(initialFilters);
  const [query, setQuery] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiNote, setAiNote] = useState<AiNote>(null);
  const [sortBy, setSortBy] = useState<SortBy>("newest");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [savedIds, setSavedIds] = useState<number[]>([]);
  const [showSavedOnly, setShowSavedOnly] = useState(false);
  const [selected, setSelected] = useState<Property | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [compareNote, setCompareNote] = useState<string | null>(null);

  const toggleSave = (id: number) => setSavedIds((prev) => toggleInArray(prev, id));

  const toggleCompare = (id: number) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((v) => v !== id);
      if (prev.length >= MAX_COMPARE) {
        setCompareNote(`You can compare up to ${MAX_COMPARE} homes at once — remove one first.`);
        return prev;
      }
      setCompareNote(null);
      return [...prev, id];
    });
  };

  const applyParsed = (parsed: Partial<Filters>, fromAi: boolean) => {
    setFilters({
      ...initialFilters,
      regions: parsed.regions || [],
      propertyTypes: parsed.propertyTypes || [],
      titleTypes: parsed.titleTypes || [],
      saleMethods: parsed.saleMethods || [],
      features: parsed.features || [],
      architecturalStyles: parsed.architecturalStyles || [],
      sunnyOnly: !!parsed.sunnyOnly,
      sunOrientations: parsed.sunOrientations || [],
      priceMin: parsed.priceMin || null,
      priceMax: parsed.priceMax || null,
      bedsMin: parsed.bedsMin || 0,
      bathsMin: parsed.bathsMin || 0,
      openHomesOnly: !!parsed.openHomesOnly,
      underCV: !!parsed.underCV,
      keyword: parsed.keyword || ""
    });
    setAiNote(fromAi ? "ai" : "fallback");
  };

  const runAiSearch = async (text: string) => {
    if (!text || !text.trim()) return;
    setAiLoading(true);
    setAiNote(null);
    try {
      const system = `You turn a short New Zealand property search sentence into a JSON object of search filters. Only use these exact values.
Regions: ${REGIONS.join(", ")}
Property types: ${PROPERTY_TYPES.join(", ")}
Title types: ${TITLE_TYPES.join(", ")}
Sale methods: ${SALE_METHODS.join(", ")}
Features: ${FEATURES.join(", ")}
Architectural styles: ${ARCHITECTURAL_STYLES.join(", ")}
Sun exposures: ${SUN_EXPOSURES.join(", ")}
Respond with ONLY a JSON object, no other text, matching exactly this shape:
{"regions":[],"propertyTypes":[],"titleTypes":[],"saleMethods":[],"features":[],"architecturalStyles":[],"sunnyOnly":false,"sunOrientations":[],"priceMin":null,"priceMax":null,"bedsMin":0,"bathsMin":0,"openHomesOnly":false,"underCV":false,"keyword":""}
Set sunnyOnly true only for a general "sunny" or "north-facing" request. Use sunOrientations for a specific compass direction mentioned. Use keyword only for a suburb or address fragment mentioned that is not already a region. Leave arrays empty and numbers null/0/false when not mentioned.`;
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system,
          messages: [{ role: "user", content: text }]
        })
      });
      if (!res.ok) throw new Error("bad response");
      const data = await res.json();
      const raw = (data.content || []).map((b: any) => b.text || "").join("");
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      applyParsed(parsed, true);
    } catch {
      applyParsed(naiveParse(text), false);
    } finally {
      setAiLoading(false);
    }
  };

  const removeChip = (chip: Chip) => {
    setFilters((prev) => {
      const next: any = { ...prev };
      if (["regions", "propertyTypes", "titleTypes", "saleMethods", "features", "architecturalStyles", "sunOrientations"].includes(chip.type)) {
        next[chip.type] = (prev as any)[chip.type].filter((v: string) => v !== chip.value);
      } else if (chip.type === "keyword") next.keyword = "";
      else if (["openHomesOnly", "underCV", "freshOnly", "sunnyOnly"].includes(chip.type)) next[chip.type] = false;
      else if (["bedsMin", "bathsMin", "parkingMin", "landAreaMin", "floorAreaMin"].includes(chip.type)) next[chip.type] = 0;
      else next[chip.type] = null;
      return next as Filters;
    });
  };

  const filtered = useMemo(() => {
    let list = filterProperties(PROPERTIES, filters);
    if (showSavedOnly) list = list.filter((p) => savedIds.includes(p.id));
    return sortProperties(list, sortBy);
  }, [filters, sortBy, showSavedOnly, savedIds]);

  const chips = useMemo(() => buildChips(filters), [filters]);
  const activeFilterCount = chips.length;

  return (
    <div className="hg-app">
      <style>{styles}</style>

      <header className="hg-header">
        <div className="hg-logo">
          <span className="hg-logo-mark"><Home size={16} /></span>
          Home Ground
        </div>
        <div className="hg-header-actions">
          <button className="hg-header-icon-btn" onClick={() => setShowCalculator(true)}>
            <Calculator size={15} /> Mortgage calculator
          </button>
          <button className={"hg-saved-toggle" + (showSavedOnly ? " active" : "")} onClick={() => setShowSavedOnly((s) => !s)}>
            <Heart size={15} fill={showSavedOnly ? "#fff" : "none"} /> Saved ({savedIds.length})
          </button>
        </div>
      </header>

      <section className="hg-hero">
        <h1 className="hg-serif">Search homes the way you'd describe them, not the way a form makes you.</h1>
        <p className="sub">Type a sentence and the search does the sorting, or use the filters on the left for full control — including title type, council value comparisons, and feature combinations most sites don't offer.</p>

        <div className="hg-ai-bar">
          <Sparkles size={18} color="#24463B" />
          <input
            type="text"
            placeholder="e.g. sunny 3-bed freehold near Hillcrest under $900k with a heat pump"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") runAiSearch(query); }}
          />
          <button className="hg-ai-submit" disabled={aiLoading} onClick={() => runAiSearch(query)}>
            {aiLoading ? <Loader2 size={15} className="hg-spin" /> : <Search size={15} />}
            {aiLoading ? "Reading that..." : "Search"}
          </button>
        </div>

        <div className="hg-ai-examples">
          {[
            "Cross-lease home with a heat pump in Hamilton",
            "Freehold section over 500m² near Halswell",
            "2 bed apartment under $650k with parking",
            "North-facing house with solar in Hawke's Bay"
          ].map((ex) => (
            <button key={ex} className="hg-example-pill" onClick={() => { setQuery(ex); runAiSearch(ex); }}>{ex}</button>
          ))}
        </div>

        {aiNote === "ai" && (
          <p className="hg-ai-note"><Sparkles size={13} /> Filters set from your sentence — refine further on the left.</p>
        )}
        {aiNote === "fallback" && (
          <p className="hg-ai-note"><Sparkles size={13} /> Matched using quick keyword search (AI parsing unavailable right now).</p>
        )}

        <div className="hg-stats">
          <div className="hg-stat"><b className="hg-serif">{PROPERTIES.length}</b><span>homes listed</span></div>
          <div className="hg-stat"><b className="hg-serif">{REGIONS.length}</b><span>regions covered</span></div>
          <div className="hg-stat"><b className="hg-serif">4</b><span>title types filterable</span></div>
        </div>
      </section>

      <div className="hg-main">
        <aside className="hg-sidebar">
          <FilterPanel filters={filters} setFilters={setFilters} />
        </aside>

        <main>
          <div className="hg-toolbar">
            <p className="hg-result-count"><b>{filtered.length}</b> {filtered.length === 1 ? "home" : "homes"} match{showSavedOnly ? " your saved list" : ""}</p>
            <div className="hg-toolbar-right">
              <button className="hg-mobile-filter-btn" onClick={() => setDrawerOpen(true)}>
                <SlidersHorizontal size={14} /> Filters {activeFilterCount > 0 ? `(${activeFilterCount})` : ""}
              </button>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <ArrowUpDown size={14} color="#6B7268" />
                <select className="hg-sort-select" value={sortBy} onChange={(e) => setSortBy(e.target.value as SortBy)}>
                  <option value="newest">Newest first</option>
                  <option value="priceAsc">Price: low to high</option>
                  <option value="priceDesc">Price: high to low</option>
                  <option value="landDesc">Largest land</option>
                  <option value="floorDesc">Largest floor area</option>
                  <option value="pricePerM2Asc">Best price per m²</option>
                </select>
              </div>
              <div className="hg-view-toggle">
                <button className={viewMode === "grid" ? "active" : ""} onClick={() => setViewMode("grid")}><LayoutGrid size={15} /></button>
                <button className={viewMode === "list" ? "active" : ""} onClick={() => setViewMode("list")}><List size={15} /></button>
              </div>
            </div>
          </div>

          {chips.length > 0 && (
            <div className="hg-chips">
              {chips.map((chip, i) => (
                <span key={chip.type + chip.label + i} className="hg-chip">
                  {chip.label}
                  <button onClick={() => removeChip(chip)}><X size={12} /></button>
                </span>
              ))}
            </div>
          )}

          {filtered.length === 0 ? (
            <div className="hg-empty">
              <p className="hg-serif" style={{ fontSize: 20, marginBottom: 6 }}>No homes match yet</p>
              <p>Try widening the price range or dropping a feature filter.</p>
              <button onClick={() => { setFilters(initialFilters); setShowSavedOnly(false); }}>Clear all filters</button>
            </div>
          ) : (
            <div className={viewMode === "grid" ? "hg-grid" : "hg-list"}>
              {filtered.map((p) => (
                <PropertyCard key={p.id} p={p} isSaved={savedIds.includes(p.id)} onToggleSave={toggleSave} onOpen={setSelected}
                  isComparing={compareIds.includes(p.id)} onToggleCompare={toggleCompare} />
              ))}
            </div>
          )}
        </main>
      </div>

      {drawerOpen && (
        <>
          <div className="hg-drawer-overlay" onClick={() => setDrawerOpen(false)} />
          <div className="hg-drawer">
            <div className="hg-drawer-header">
              <p className="hg-serif" style={{ fontSize: 18, fontWeight: 600, margin: 0 }}>Filters</p>
              <button onClick={() => setDrawerOpen(false)} style={{ background: "none", border: "none", cursor: "pointer" }}><X size={20} /></button>
            </div>
            <FilterPanel filters={filters} setFilters={setFilters} />
            <button className="hg-drawer-apply" onClick={() => setDrawerOpen(false)}>Show {filtered.length} homes</button>
          </div>
        </>
      )}

      {selected && (
        <PropertyModal p={selected} onClose={() => setSelected(null)} isSaved={savedIds.includes(selected.id)} onToggleSave={toggleSave} />
      )}

      {compareIds.length > 0 && !showCompare && (
        <div className="hg-compare-bar">
          <span>{compareIds.length} home{compareIds.length > 1 ? "s" : ""} selected to compare{compareNote ? ` — ${compareNote}` : ""}</span>
          <div className="hg-compare-bar-actions">
            <button className="hg-compare-clear-btn" onClick={() => { setCompareIds([]); setCompareNote(null); }}>Clear</button>
            <button className="hg-compare-view-btn" disabled={compareIds.length < 2} onClick={() => setShowCompare(true)}>
              <Scale size={14} style={{ marginRight: 6, verticalAlign: "-2px" }} />
              {compareIds.length < 2 ? "Pick one more to compare" : `Compare ${compareIds.length}`}
            </button>
          </div>
        </div>
      )}

      {showCompare && (
        <CompareModal
          properties={compareProperties(PROPERTIES, compareIds)}
          onClose={() => setShowCompare(false)}
          onRemove={(id) => {
            const next = compareIds.filter((v) => v !== id);
            setCompareIds(next);
            if (next.length < 2) setShowCompare(false);
          }}
        />
      )}

      {showCalculator && (
        <MortgageCalculator onClose={() => setShowCalculator(false)} initialPrice={selected ? selected.price : 800000} />
      )}
    </div>
  );
}
